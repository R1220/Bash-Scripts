#!/bin/bash
sudo wpa_supplicant -B -i wlp3s0 -c /etc/wpa_supplicant/wifi_new
